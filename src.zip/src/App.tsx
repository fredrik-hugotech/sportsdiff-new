import React, { useState, useEffect, useCallback } from 'react';
import {
  DndContext,
  closestCenter,
  DragEndEvent,
  useDraggable,
  useDroppable
} from '@dnd-kit/core';
import { v4 as uuidv4 } from 'uuid';
import { createClient } from '@supabase/supabase-js';
import { PremiumAccess } from './PremiumAccess';
import TeamManager from './components/TeamManager';
import TeamSelector from './components/TeamSelector';
import { Link } from 'react-router-dom';
import PlayerListUploader from './components/PlayerListUploader';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

interface Player {
  id: string;
  name: string;
  level: number;
  vest: boolean;
  teamId: string;
}

interface Team {
  id: string;
  name: string;
  color: string;
}

function App() {
  const [user, setUser] = useState<null | undefined>(undefined);
  const [rawList, setRawList] = useState('');
  const [attendingRaw, setAttendingRaw] = useState('');
  const [playersPerTeam, setPlayersPerTeam] = useState<number>(6);
  const [distribution, setDistribution] = useState<'even' | 'grouped'>('even');
  const [teams, setTeams] = useState<Team[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [enableVests, setEnableVests] = useState<boolean>(true);
  const [selectedTeamId, setSelectedTeamId] = useState<string>('');
  const [savedTeamLists, setSavedTeamLists] = useState<{ id: string; name: string }[]>([]);

const teamColors = ['blue', 'red', 'green', 'yellow', 'purple', 'pink'];
const colorMap: Record<string, string> = {
  blue: 'bg-blue-100',
  red: 'bg-red-100',
  green: 'bg-green-100',
  yellow: 'bg-yellow-100',
  purple: 'bg-purple-100',
  pink: 'bg-pink-100'
};

function DraggablePlayer(props: { player: Player }) {
  const { player } = props;
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: player.id,
    data: { type: 'player', player }
  });

  const style = {
    transform: transform ? `translate(${transform.x}px, ${transform.y}px)` : undefined,
    opacity: isDragging ? 0.5 : 1
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className="border rounded-2xl p-3 mb-2 flex justify-between items-center shadow-sm cursor-grab bg-white"
    >
      <span>{player.vest ? '🦺 ' : ''}{player.name} ({player.level})</span>
    </div>
  );
}

function DroppableTeam(props: { team: Team; players: Player[] }) {
  const { team, players } = props;
  const { setNodeRef, isOver } = useDroppable({
    id: team.id,
    data: { type: 'team' }
  });

  const vestGroup = players.filter(p => p.vest);
  const noVestGroup = players.filter(p => !p.vest);

  const avg = (group: Player[]) =>
    group.length === 0 ? 0 : +(group.reduce((sum, p) => sum + p.level, 0) / group.length).toFixed(2);

  return (
    <div
      ref={setNodeRef}
      className={`rounded-2xl p-4 shadow-md min-h-[150px] transition-all duration-200 space-y-2 ${
        isOver ? 'ring-2 ring-blue-400' : ''
      } ${colorMap[team.color] || 'bg-gray-100'}`}
    >
      <h2 className="font-bold text-lg mb-1">{team.name}</h2>
  
      <p className="text-sm">
        Spillere: {players.length} | Snittnivå: {avg(players)}
      </p>
  
      {players.length > 1 && (
        <p className="text-sm text-gray-600">
          Intern lagdeling – Vester: {avg(vestGroup)} | Uten: {avg(noVestGroup)}
        </p>
      )}
  
  {[...vestGroup, ...noVestGroup].map(player => (
    <div key={player.id}>
      <DraggablePlayer player={player} />
    </div>
  ))}
    </div>
  );
}

  // Midlertidig dummy-user for utvikling:
  useEffect(() => {
    setUser({
      id: 'dev-user-123',
      email: 'dummy@sportsdiff.dev'
    });
  }, []);

  useEffect(() => {
    if (user) {
      supabase.from('profiles').select('rawList').eq('id', user.id).single()
        .then(res => {
          if (res.data?.rawList) {
            setRawList(res.data.rawList);
          }
        });
    }
  }, [user]);

  useEffect(() => {
    if (user && rawList) {
      supabase.from('profiles')
        .upsert({ id: user.id, rawList }, { onConflict: 'id' });
    }
  }, [rawList]);

  const parsePlayers = (text: string): Player[] => {
    return text
      .split('\n')
      .map(line => line.trim())
      .filter(line => line)
      .map(line => {
        const [name, levelStr] = line.split(/\s{2,}|\t/);
        return {
          id: uuidv4(),
          name: name.trim(),
          level: parseFloat(levelStr?.replace(',', '.') ?? '0'),
          vest: false,
          teamId: ''
        };
      });
  };

  const assignVestsBalanced = (players: Player[]): Player[] => {
    const result: Player[] = [];
    const teamIds = Array.from(new Set(players.map(p => p.teamId)));

    for (const teamId of teamIds) {
      const teamPlayers = players.filter(p => p.teamId === teamId);
      const sorted = [...teamPlayers].sort((a, b) => b.level - a.level);
      const groupA: Player[] = [], groupB: Player[] = [];

      sorted.forEach((player, index) => {
        (index % 2 === 0 ? groupA : groupB).push(player);
      });

      const avgA = groupA.reduce((sum, p) => sum + p.level, 0) / groupA.length || 0;
      const avgB = groupB.reduce((sum, p) => sum + p.level, 0) / groupB.length || 0;
      const vestGroup = avgA > avgB ? groupB : groupA;

      const updated = sorted.map(p => ({
        ...p,
        vest: vestGroup.some(vp => vp.id === p.id)
      }));

      result.push(...updated);
    }

    return result;
  };

  const generateTeams = useCallback(() => {
    const fullList = parsePlayers(rawList);
    const attendingNames = attendingRaw.split('\n').map(n => n.trim()).filter(n => n);

    let attending = attendingNames.map(name => {
      const p = fullList.find(p => p.name.toLowerCase() === name.toLowerCase());
      if (!p) return null;
      return { ...p, id: uuidv4() };
    }).filter(Boolean) as Player[];

    if (attending.length === 0) {
      setTeams([]);
      setPlayers([]);
      return;
    }

    attending.sort((a, b) => b.level - a.level);

    const numTeams = Math.ceil(attending.length / playersPerTeam);
    const newTeams: Team[] = Array.from({ length: numTeams }, (_, i) => ({
      id: uuidv4(),
      name: `Lag ${i + 1}`,
      color: teamColors[i % teamColors.length]
    }));

    const assigned: Player[] = [];

    if (distribution === 'even') {
      const teamBuckets = Array.from({ length: numTeams }, () => [] as Player[]);
      let index = 0;
      while (attending.length > 0) {
        const player = attending.shift();
        if (player) {
          teamBuckets[index].push(player);
          index = (index + 1) % numTeams;
        }
      }
      teamBuckets.forEach((bucket, i) => {
        bucket.forEach(player => assigned.push({ ...player, teamId: newTeams[i].id }));
      });
    } else {
      for (let i = 0; i < newTeams.length; i++) {
        const group = attending.splice(0, playersPerTeam);
        group.forEach(p => assigned.push({ ...p, teamId: newTeams[i].id }));
      }
    }

    const withVests = enableVests ? assignVestsBalanced(assigned) : assigned;
    setTeams(newTeams);
    setPlayers(withVests);
  }, [rawList, attendingRaw, playersPerTeam, distribution, enableVests]);

  useEffect(() => {
    if (rawList && attendingRaw) generateTeams();
  }, [playersPerTeam, distribution, enableVests]);

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over) return;

    const activePlayer = active.data?.current?.player as Player;
    const newTeamId = over.id as string;

    if (activePlayer.teamId !== newTeamId) {
      const updated = players.map(p =>
        p.id === activePlayer.id ? { ...p, teamId: newTeamId } : p
      );
      const withVests = enableVests ? assignVestsBalanced(updated) : updated;
      setPlayers(withVests);
    }
  };

  const filteredTeams = selectedTeamId
    ? teams.filter(t => t.id === selectedTeamId)
    : teams;

    if (user === undefined) {
      return <div className="p-4 text-gray-600">Laster tilgang...</div>;
    }
    
    if (user === null) {
      return (
        <div className="p-4 text-center text-gray-700">
          <p>Du er ikke logget inn.</p>
          <p className="text-sm mt-2">⚠️ Begrenset funksjonalitet tilgjengelig.</p>
          {/* Du kan legge til en innloggingsknapp her senere */}
        </div>
      );
    }

  return (
    <PremiumAccess user={user}>
      <div>
          <div className="mb-4">
            <h2 className="font-semibold mb-1">📝 Lim inn spillerliste</h2>
            <textarea
              className="w-full border rounded p-2"
              rows={6}
              value={rawList}
              onChange={e => setRawList(e.target.value)}
              placeholder="Navn og nivå, f.eks. Ola Nordmann 3.2"
            />
          </div>

          <div className="flex justify-end mb-4">
            <Link
              to="/rediger-spillerliste"
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded shadow"
            >
              Rediger lagliste
            </Link>
          </div>
          <TeamManager user={user} players={players} />
          <TeamSelector
            teams={savedTeamLists.map(list => ({ id: list.id, name: list.name }))}
            currentTeamId={selectedTeamId}
            onSelect={setSelectedTeamId}
          />

          <textarea
            placeholder="Påmeldte spillere - lim inn"
            className="w-full border mb-2 p-2 rounded"
            rows={4}
            value={attendingRaw}
            onChange={e => setAttendingRaw(e.target.value)}
          />

          <div className="flex flex-wrap items-center gap-4 mb-4">
            <label>
              Spillere pr lag:
              <input
                type="number"
                min={2}
                max={22}
                value={playersPerTeam}
                onChange={e => setPlayersPerTeam(Number(e.target.value))}
                className="ml-2 border px-2 py-1 w-16 rounded"
              />
            </label>

            <label>
              <select
                value={distribution}
                onChange={e => setDistribution(e.target.value as 'even' | 'grouped')}
                className="border px-2 py-1 rounded"
              >
                <option value="even">Jevne lag</option>
                <option value="grouped">Differensierte lag</option>
              </select>
            </label>

            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={enableVests}
                onChange={() => setEnableVests(!enableVests)}
              /> Vester
            </label>

            <button
              onClick={generateTeams}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded shadow"
            >
              Generer lag
            </button>
          </div>

          <DndContext
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {filteredTeams.map(team => {
                const teamPlayers = players.filter(p => p.teamId === team.id);
                return (
                  <div key={team.id}>
                    <DroppableTeam team={team} players={teamPlayers} />
                  </div>
                );
              })}
            </div>
          </DndContext>
        </div>
    </PremiumAccess>
  );
} // 👈 Sørg for at denne finnes og avslutter function App

export default App;
export const STRIPE_PRICE_ID = import.meta.env.VITE_STRIPE_PRICE_ID!;
export const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY!;
export const STRIPE_SECRET_KEY = import.meta.env.VITE_STRIPE_SECRET_KEY!;

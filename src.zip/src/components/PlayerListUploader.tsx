export default function PlayerListUploader() {
  return null;
}
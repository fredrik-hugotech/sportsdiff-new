import React, { useState, useEffect } from 'react';
import type { Dispatch, SetStateAction } from 'react';
import { supabase } from '../supabaseClient';

const CATEGORIES = [
  'Teknikk', 'Innsats', 'Fysisk form', 'Forståelse',
  'Oppmøte', 'Avslutninger', 'Offensivt', 'Defensivt'
];

const DEVELOPMENT = ['Utvikling 1', 'Utvikling 2', 'Utvikling 3'];

interface Player {
  id: string;
  name: string;
  position: string;
  level: number;
  previous_level?: number;
  categories?: Record<string, number>;
  development?: Record<string, number>;
}

interface Props {
  player: Player;
  onSave: (updated: Player) => void;
  onCancel: () => void;
}

export default function PlayerEditor({ player, onSave, onCancel }: Props) {
  const [level, setLevel] = useState<number>(player.level);
  const [categories, setCategories] = useState<Record<string, number>>(player.categories ?? {});
  const [development, setDevelopment] = useState<Record<string, number>>(player.development ?? {});

  const handleChange = (
    group: Record<string, number>,
    setGroup: React.Dispatch<React.SetStateAction<Record<string, number>>>,
    key: string,
    value: number
  ) => {
    setGroup({ ...group, [key]: value });
  };

  const handleSave = async () => {
    const previous_level = level !== player.level ? player.level : player.previous_level;

    const updatedPlayer: Player = {
      ...player,
      level,
      previous_level,
      categories,
      development
    };

    console.log('📤 Lagrer til Supabase:', updatedPlayer);

    const { data, error } = await supabase
      .from('players')
      .update({
        level,
        previous_level,
        categories,
        development
      })
      .eq('id', player.id)
      .select();

    if (error) {
      console.error('❌ Feil ved lagring til Supabase:', error);
      return;
    }

    console.log('✅ Lagret spiller:', data);
    onSave(updatedPlayer);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md space-y-4 shadow-lg">
        <h2 className="text-xl font-bold">Rediger {player.name}</h2>

        <label className="block">
          Nivå:
          <input
            type="number"
            value={level}
            onChange={e => setLevel(parseFloat(e.target.value))}
            className="border w-full p-2 rounded mt-1"
          />
        </label>

        <div>
          <h3 className="font-semibold">Kategorier (1–3)</h3>
          {CATEGORIES.map(key => (
            <label key={key} className="block text-sm mt-1">
              {key}
              <input
                type="number"
                min={1}
                max={3}
                value={categories[key] ?? ''}
                onChange={e =>
                  handleChange(categories, setCategories, key, Number(e.target.value))
                }
                className="border p-1 rounded ml-2 w-16"
              />
            </label>
          ))}
        </div>

        <div>
          <h3 className="font-semibold mt-4">Utviklingsområder (1–5)</h3>
          {DEVELOPMENT.map(key => (
            <label key={key} className="block text-sm mt-1">
              {key}
              <input
                type="number"
                min={1}
                max={5}
                value={development[key] ?? ''}
                onChange={e =>
                  handleChange(development, setDevelopment, key, Number(e.target.value))
                }
                className="border p-1 rounded ml-2 w-16"
              />
            </label>
          ))}
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400"
          >
            Avbryt
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 rounded bg-green-600 hover:bg-green-700 text-white"
          >
            Lagre
          </button>
        </div>
      </div>
    </div>
  );
}
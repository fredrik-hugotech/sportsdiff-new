import React, { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { createClient } from '@supabase/supabase-js';
import { usePlayerList } from '../contexts/PlayerListContext';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

interface SavedTeam {
  id: string;
  user_id: string;
  name: string;
  team_data: any[]; // this was missing
  created_at: string;
}

export default function TeamManager({
  user,
  players
}: {
  user: any;
  players: any[];
}) {
  const [teamName, setTeamName] = useState('');
  const [savedTeams, setSavedTeams] = useState<SavedTeam[]>([]);
  const { setPlayerList } = usePlayerList();

  useEffect(() => {
    if (user) {
      supabase
        .from('saved_teams')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .then(({ data }) => {
          if (data) setSavedTeams(data);
        });
    }
  }, [user]);

  const saveTeam = async () => {
    if (!teamName.trim()) return;

    await supabase.from('saved_teams').insert({
      id: uuidv4(),
      user_id: user.id,
      name: teamName.trim(),
      team_data: players,
      created_at: new Date().toISOString()
    });

    setTeamName('');
    const { data } = await supabase
      .from('saved_teams')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    if (data) setSavedTeams(data);
  };

  const loadTeam = (team: SavedTeam) => {
    setPlayerList(team.team_data); // Setter spillerlisten i context
  };

  return (
    <div className="mb-6">
      <h3 className="font-bold text-lg mb-2">Lagre eller hent laglister</h3>
      <div className="flex gap-2 mb-2">
        <input
          type="text"
          placeholder="Navn på lagliste"
          value={teamName}
          onChange={e => setTeamName(e.target.value)}
          className="border rounded px-2 py-1 flex-1"
        />
        <button
          onClick={saveTeam}
          className="bg-blue-500 text-white rounded px-4 py-1"
        >
          Lagre
        </button>
      </div>
      {savedTeams.length > 0 && (
        <div className="space-y-1">
          {savedTeams.map(team => (
            <div
              key={team.id}
              className="flex justify-between items-center border px-2 py-1 rounded"
            >
              <span>{team.name}</span>
              <button
                onClick={() => loadTeam(team)}
                className="text-sm text-blue-600 underline"
              >
                Last inn
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

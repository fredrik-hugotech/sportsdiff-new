import React from 'react';

const categories = [
  'teknikk',
  'innsats',
  'fysisk_form',
  'forstaelse',
  'oppmote',
  'avslutninger',
  'offensivt',
  'defensivt'
];

export default function PlayerCardEditor({
  player,
  onChange
}: {
  player: any;
  onChange: (updated: any) => void;
}) {
  const handleValueChange = (field: string, value: number) => {
    const updated = { ...player, [field]: value };
    onChange(updated);
  };

  return (
    <div className="border rounded-lg p-4 shadow-sm bg-white">
      <h4 className="font-semibold text-lg mb-2">
        {player.name} (nivå: {player.level})
      </h4>
      <div className="grid grid-cols-2 gap-2 text-sm">
        {categories.map(cat => (
          <label key={cat} className="flex items-center gap-2">
            {cat.charAt(0).toUpperCase() + cat.slice(1)}:
            <input
              type="number"
              min={1}
              max={5}
              value={player[cat] || ''}
              onChange={e => handleValueChange(cat, Number(e.target.value))}
              className="border px-1 py-0.5 w-12 rounded"
            />
          </label>
        ))}
      </div>
    </div>
  );
}

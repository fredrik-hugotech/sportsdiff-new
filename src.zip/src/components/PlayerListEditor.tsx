import React, { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

interface PlayerProfile {
  id: string;
  user_id: string;
  name: string;
  level: number;
  speed: number;
  strength: number;
  technique: number;
  position: string;
}

export default function PlayerListEditor({ user }: { user: any }) {
  const [players, setPlayers] = useState<PlayerProfile[] | undefined>(undefined);

  useEffect(() => {
    if (!user) return;

    const loadPlayers = async () => {
      const { data, error } = await supabase
        .from('players')
        .select('*')
        .eq('user_id', user.id)
        .order('name');

      if (error) {
        console.error('Feil ved henting av spillere:', error.message);
      } else {
        console.log(data);
        setPlayers(data || []);
      }
    };

    loadPlayers();
  }, [user]);

  const updatePlayer = async (player: PlayerProfile, field: keyof PlayerProfile, value: any) => {
    const updatedPlayer = { ...player, [field]: value };
    setPlayers(prev =>
      prev ? prev.map(p => (p.id === player.id ? updatedPlayer : p)) : prev
    );

    const { error } = await supabase
      .from('players')
      .update({ [field]: value })
      .eq('id', player.id);

    if (error) {
      console.error('Feil ved oppdatering:', error.message);
    }
  };

  if (players === undefined) {
    return (
      <div className="p-4 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Rediger spillerliste</h2>
        <p>Laster spillere...</p>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Rediger spillerliste</h2>
      {players.length === 0 ? (
        <p>Ingen spillere funnet.</p>
      ) : (
        <table className="w-full border">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 border">Navn</th>
              <th className="p-2 border">Nivå</th>
              <th className="p-2 border">Fart</th>
              <th className="p-2 border">Styrke</th>
              <th className="p-2 border">Teknikk</th>
              <th className="p-2 border">Posisjon</th>
            </tr>
          </thead>
          <tbody>
            {players.map(player => (
              <tr key={player.id}>
                <td className="p-2 border">{player.name}</td>
                {['level', 'speed', 'strength', 'technique'].map(field => (
                  <td key={field} className="p-2 border">
                    <input
                      type="number"
                      value={(player as any)[field] ?? ''}
                      onChange={e => updatePlayer(player, field as keyof PlayerProfile, parseFloat(e.target.value))}
                      className="w-full border px-2 py-1 rounded"
                    />
                  </td>
                ))}
                <td className="p-2 border">
                  <input
                    type="text"
                    value={player.position || ''}
                    onChange={e => updatePlayer(player, 'position', e.target.value)}
                    className="w-full border px-2 py-1 rounded"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
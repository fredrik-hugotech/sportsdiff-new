import { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';

export function useUser() {
  const [user, setUser] = useState(() => supabase.auth.getUser());

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data?.user ?? null);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });

    return () => {
      listener?.subscription.unsubscribe();
    };
  }, []);

  return user;
}

import React, {
  createContext,
  useState,
  useContext,
} from 'react';
import type { ReactNode } from 'react';

interface Player {
  id: string;
  name: string;
  level: number;
  vest: boolean;
  teamId: string;
}

interface PlayerListContextType {
  players: Player[];
  setPlayers: (players: Player[]) => void;
}

const PlayerListContext = createContext(undefined as unknown as PlayerListContextType);

type PlayerListProviderProps = {
  children: ReactNode;
};

export const PlayerListProvider = ({ children }: PlayerListProviderProps) => {
  const [players, setPlayers] = useState<Player[]>([]);

  return (
    <PlayerListContext.Provider value={{ players, setPlayers }}>
      {children}
    </PlayerListContext.Provider>
  );
};

export const usePlayerList = () => {
  const context = useContext(PlayerListContext as unknown as React.Context<PlayerListContextType>);
  if (!context) {
    throw new Error('usePlayerList must be used within a PlayerListProvider');
  }
  return context;
};

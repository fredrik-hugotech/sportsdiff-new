import React, { ReactNode } from 'react';

type PremiumAccessProps = {
  user: any;
  children?: React.ReactNode; // merk ?: gjør children valgfri
};

export function PremiumAccess({ user, children = null }: PremiumAccessProps) {
  if (!user) {
    return <div>Please log in to access premium features.</div>;
  }
  return <>{children}</>;
}
